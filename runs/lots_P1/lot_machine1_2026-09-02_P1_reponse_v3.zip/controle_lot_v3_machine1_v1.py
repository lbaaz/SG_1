"""Controle machine 1 du lot v3 machine 2 : releve independant de s*(T) depuis les grilles,
verdict DIRECT/PIEGE, et pour les directes l'affine eps*t = F0 + B*eps (F0, B), eps(s*) pour les piegees."""
import json, numpy as np
L='/home/claude/lot_m2_v3/'
rows=[]
for f in ['mesures_gel_site4_cusploin_machine2_v4.json','mesures_gel_regle_amendee_machine2_v5.json','mesures_gel_ordre_total_machine2_v6.json']:
    d=json.load(open(L+f))
    for jam in ('C','E','F'):
        for r in d.get(jam,[]):
            g=np.array(r['grille']); t=np.array(r['t_exp']); p=r['p']; w2=r['w2']; dl=w2*w2-1
            def sT(T):
                sel=(t>0)&(t<=T); return float(g[sel].min()) if sel.any() else None
            s4,s16=sT(400),sT(1600)
            conforme = (abs(s4-r['s_400'])<1e-15) and (abs(s16-r['s_1600'])<1e-15) if (s4 and s16) else None
            dln=np.log(s16/s4) if (s4 and s16) else None
            verdict='DIRECT' if (dln is not None and dln<-0.10) else 'PIEGE'
            ok=t>0; F0=B=None
            if verdict=='DIRECT' and ok.sum()>=6:
                eps=0.05*g[ok]**(p-2)/dl; B,F0=np.polyfit(eps,eps*t[ok],1)
            eps_s4=0.05*s4**(p-2)/dl if s4 else None
            rows.append((f[12:22],jam,p,w2,r['sgn'],s4,s16,dln,verdict,r.get('pred_direct'),conforme,F0,B,eps_s4,int(ok.sum())))
print("%-10s %s %2s %6s %3s %11s %11s %8s %7s %7s %5s %9s %8s %9s %3s"%('gel','J','p','w2','sgn','s*(400)','s*(1600)','dln','verd.','pred_m2','conf','F0','B','eps(s*4)','n'))
for r in rows:
    print("%-10s %s %2d %6.3f %+3d %11.6f %11.6f %8.4f %7s %7s %5s %9s %8s %9.2e %3d"%(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8],str(r[9]),str(r[10]),("%.4g"%r[11]) if r[11] else '-',("%.1f"%r[12]) if r[12] else '-',r[13],r[14]))
