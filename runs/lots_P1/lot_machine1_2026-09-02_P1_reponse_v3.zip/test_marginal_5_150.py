import json, time, sys, numpy as np
sys.path.insert(0,'/home/claude')
from charge_moteur import charger
from integrer_indice import integrer_indice
m=charger(); m.P=5
w2=1.5; d=w2*w2-1; G=0.2127; F_pred=G/d
s=np.logspace(np.log10(0.05), np.log10(0.35), 48)
eps=0.05*s**3/d; t_pred=F_pred/eps
print("PREDICTION (modele reduit, canal deverrouille a petit eps) : t = %.3f/eps"%F_pred)
t0=time.time(); e,idx=integrer_indice(m,w2,s,+1,t_max=25600.0); tex=np.where(idx>=0, idx*m.DT, -1.0)
print("duree %.0f s ; explosifs %d/48 a T=25600"%(time.time()-t0, int(e.sum())))
for si,ti,tp in zip(s,tex,t_pred):
    print("  s=%.4f  eps=%.2e  t_pred=%8.0f  t_mesure=%s"%(si,0.05*si**3/d,tp, ("%.0f"%ti) if ti>0 else "-"))
json.dump(dict(cellule='5|1.50|+1',T=25600,s=s.tolist(),t_exp=tex.tolist(),F_pred=F_pred,G=G,delta=d), open('/home/claude/test_marginal_5_150.json','w'), indent=1)
