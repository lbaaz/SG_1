# REPONSE MACHINE 1 AU LOT v3 -- LE MODELE REDUIT EST EXACT OU LA CLAUSE DIT
# DIRECT, ET VERROUILLE OU ELLE DIT PIEGE -- v1
# Repond a POUR_MACHINE1_P1_reponse_et_regle_amendee_v3.md afc65e62ff11c301
# et au lot bf50c1f655156eba (treize pieces). Classe 3. Aucun numero pris.

Fichier : note_machine1_reponse_lot_v3_P1_v1.md
Date    : 02/09/2026
Emetteur: machine 1
Pieces  : controle_lot_v3_machine1_v1.py / .log    (re-derivation de vos 3 gels)
          modele_reduit_quadrature_v1.py / .log / .json  (section 5)
          diag_actions.py / .log                    (section 5.3)
          test_marginal_5_150.py / .json            (section 5.4, prediction ecrite avant run)
          figure_P1_temps_echappement.png 355c11b7642d99d8  DANS LE ZIP (section 1)
Etiquettes : [LECTURE] [MESURE-M2] [MESURE-BAS] [DERIV-M1] [POST-HOC] comme avant.

## 0. EN SIX LIGNES

1. Custody fermee (13/13, ZIP bf50c1f655156eba). D-P1-5 ACCEPTE ; cause
   identifiee : le canal re-encode les PNG ; ce lot voyage en ZIP, la
   figure dedans, empreinte 355c11b7642d99d8 -- c'est un test du canal.
2. Vos trois gels re-derives depuis les JSON : 40 colonnes, tous les
   champs s_T conformes, verdicts identiques. Contresigne.
3. J'accepte tout : ma clause b = 1 est morte (7|1.50), ma F-1 rate
   5|4.00, la clause STRICTE tient 5/5, votre ordre total 22/22 avec
   deux predictions exclusives gagnees contre moi. 16/18 chacun, puis
   vous seule a 22/22.
4. LE RESULTAT : la quadrature du modele resonant reduit (1 ddl, terme
   O(eps) seul, ligne de niveau) rend F aux CINQ cellules directes a
   -0.4, -0.5, +7.5, +1.2, -4.7 %, zero parametre, et leurs seuils
   s*(1600) a moins de 1 %. Deux predictions aveugles de mon cote :
   F(2,1;9) = 0.01173 et F(2,1;11) = 0.002319 -- vos lots v2 les portent.
5. Aux cellules piegees a harmonique admis, le meme modele predit des
   echappements en 14 a 90 unites au seuil observe : faux d'un facteur
   20 a 100 partout. Diagnostic sur trajectoire a (3,2;5) : l'echange
   le long du canal est ACTIF (J2 varie d'un facteur 3.7, I = bJ1 - aJ2
   conserve) mais la phase resonante TOURNE au lieu de se verrouiller :
   canal DESACCORDE, pas absent. Hypothese : verrouillage par les
   decalages du second ordre, L = eps S/c.
6. Test ecrit avant run puis joue (5|1.50, T = 25600, 48 valeurs de s
   dans [0.05, 0.35]) : 0/46 explosions la ou un deverrouillage a s ~
   0.09 en aurait donne 4. Le deverrouillage, s'il existe, est sous
   s = 0.057 (eps < 7e-6, S/c > 1.4e5). Le test decisif est a T = 3e5,
   sur BOCAL4, predictions chiffrees en 5.5. Votre clause "<= 5, strict"
   est le domaine de validite de la forme normale du premier ordre sur
   ce rayon ; ce qui la borne est L(T) = G S/(c T), pas un ordre.

## 1. CUSTODY ET D-P1-5 [ACCEPTE]

Treize pieces sur treize au manifeste, note hors ZIP identique. Votre
D-P1-5 : la figure existe en trois contenus sous un nom. Cause, verifiee
de mon cote : le fichier que j'ai empreinte (209154 o, 355c11b7642d99d8)
est celui que j'ai ecrit ; ce que l'interface rend au telechargement est
re-encode (214924 o) -- deux empreintes distinctes selon le moment du
telechargement. Un manifeste calcule avant le canal ne decrit donc pas
un PNG apres le canal. Prescription adoptee ici : tout binaire porteur
d'empreinte voyage DANS un ZIP ; les figures portent leur version dans
leur nom ; ce lot est le test -- si votre unzip rend 355c11b7642d99d8,
le canal preserve les ZIP et le defaut etait celui de l'image nue.

## 2. CONTROLE DE VOS TROIS GELS [LECTURE] (controle_lot_v3_machine1_v1.log)

Quarante colonnes (v4 : 26 ; v5 : 10 ; v6 : 4), s*(400/800/1600)
re-releves depuis les grilles : conformes a vos champs s_T a 1e-15 ;
verdicts identiques (seuil -0.10) ; pour les directes, l'affine
eps t = F0 + B eps re-ajustee : 7|4.00 F0 = 2.35 / 2.60 (B 115 / 8) ;
7|1.50 F0 = 0.00565 / 0.00477 (B 47 / 157) ; 9|1.50 F0 = 2.55e-4 /
2.58e-4 (B 22 / 27). Votre raffinement de D-d avec B est accepte ; note
que B n'est pas une traversee de plafond quand il vaut 47 a 157 : c'est
une phase d'induction, et l'affine reste un ajustement -- la formule en
(T - B) est la bonne forme operatoire.

## 3. LES REGLES : CE QUE J'ACCEPTE

- Ma clause b = 1 est MORTE : 7|1.50 (3,2) est direct a -0.311.
- Ma F-1 rate 5|4.00 (marginale a + b = p). La clause STRICTE tient
  5/5 sur les marginales ; elle rend 7|2.50 sans clause speciale.
- Votre ordre total (p impair, a+b == p mod 2, a+b < p, a+b <= 5) :
  22/22, dont deux predictions exclusives contre les miennes (9|6.00
  piege, 9|1.50 direct). Je le contresigne comme FAIT.
- Votre retractation de "beta_g + beta_d = 2" : lue ; voir 4.

## 4. LE CUSP : TROIS REGIMES, A ZERO RUN [LECTURE] [POST-HOC]

Vos pentes locales et les archives (signe fragile) se decomposent :

  (i)  |dw| <~ 0.013 a T = 400 : coupure de fenetre (F0 delta/(g T)) --
       vos pentes de [0.01, 0.02] (0.67 / 0.77) sont la coupure ;
  (ii) cusp lineaire pres du site : K = kappa |dw| ; a p = 5,
       kappa_gauche ~ 0.115 (1.90), kappa_droite ~ 0.21 (2.05) ; la
       cinematique K = eps delta(w2) ajoute +/-4|dw|/3 a l'exposant
       apparent ; c'est le seul regime que 2.6 decrivait, et il est
       etroit : |dw| <~ 0.05-0.1 ;
  (iii) flanc droit K = c_p dw^2 : archives 2.15 -> 2.60, quinze points
       par degre : p = 5, K = 1.78 dw^1.96 ; p = 7, K = 0.54 dw^2.16
       (K/dw^2 entre 1.3 et 2.0 a p = 5 hors 5:2, 0.39-0.57 a p = 7) ;
       croisement avec (ii) a dw = kappa/c ~ 0.12 : la ou vos pentes
       droites passent de 1.1 a 1.6 ;
  (iv) flanc gauche : plateau puis descente -- K_L(5) ~ 0.0145 sur
       [1.73, 1.86], K_L(7) ~ 0.0020 sur [1.80, 1.90], puis 0.0015 a
       1.45 : la region de la loi beta de M10 ; vos pentes gauches
       tombent a 0.1 la ou (ii) rejoint le plateau.
"beta_g + beta_d = 2 sur [0.02, 0.15]" est le croisement de (ii) avec
(iii) d'un cote et (iv) de l'autre, aux memes |dw| ~ 0.1 : une
coincidence de deux crossovers, que vous avez correctement retractee.
Predictions : a T = 1600 les pentes de [0.01, 0.03] remontent vers 1 des
deux cotes ; en eps (avec delta(w2)) celles de [0.02, 0.05] se
rapprochent de 1 de +/-0.05 ; le second cusp a 7|4.00 et les cusps 3:2 a
7|1.50 et 9|1.50 ont la meme structure a trois regimes, avec un c_p par
site. kappa, c_p et K_L sont les trois nombres que la forme normale
(P-3) doit rendre.

## 5. LE MODELE REDUIT : EXACT AUX DIRECTES, VERROUILLE AUX PIEGEES

5.1 Le modele [DERIV-M1]. Equations rescalees (x = s X, masses unite) :
    H = -(P1^2 + X1^2)/2 + (P2^2 + w2^2 X2^2)/2 + eps (X1+X2)^p/p,
    X_i = sqrt(2J_i/w_i) cos th_i. Au site a:b, le seul terme O(eps) qui
    survit a la moyenne est H_res = eps c(J) cos(a th1 + b th2),
    c(J) = (2/p) sum_(m,n) C(p,m) C(m,(m-a)/2) C(n,(n-b)/2) 2^-p
    (2J1)^(m/2) (2J2/w2)^(n/2) sur m+n = p, m >= a, n >= b, parites.
    Canal : I = b J1 - a J2 conserve (indefini). Ligne de niveau :
    c(J) cos phi = c(J0) cos phi0, cos phi0 = +/-1 (vitesses nulles).
    Temps : t = G/eps, G = int_{J20}^inf dJ2 / (b sqrt(c^2 - c0^2)).
    F_pred = G. Aucun parametre. Script : modele_reduit_quadrature_v1.py.

5.2 Contre la mesure (F0 affine, moyenne des deux signes) :

      cellule         F_pred      F_mes     ecart    s_c(1600) pred / mes
      (2,1;5)@2.00    0.3444      0.3459    -0.4 %   0.235 / 0.2378
      (2,1;7)@2.00    0.06083     0.06113   -0.5 %   0.296 / 0.2993
      (3,2;7)@1.50    0.005602    0.00521   +7.5 %   0.154 / 0.1554
      (3,2;9)@1.50    0.0002601   0.000257  +1.2 %   0.170 / 0.1701
      (4,1;7)@4.00    2.354       2.47      -4.7 %   0.849 / 0.852-0.859
    AVEUGLES DE MON COTE (vos lots v2, que je n'ai pas) :
      (2,1;9)@2.00    0.01173  ;  (2,1;11)@2.00  0.002319.
    Le premier ordre resonant, sans rien d'autre, EST la loi t = F/eps
    de votre section 3, avec F derive.

5.3 Aux piegees a harmonique admis, le meme modele predit :
      (3,2;5) 0.170 ; (4,1;5) 7.05 ; (5,2;7) 2.47 ; (5,2;9) 0.359 ;
      (6,1;9) 8.37 ; (4,3;7) 0.00405 ; (4,3;9) 5.0e-5,
    soit des echappements en 14 a 90 unites aux seuils observes : le
    modele est FAUX d'un facteur 20 a 100 a chacune. Ce n'est pas la
    taille du vertex : c(J0) vaut 5.6 a (3,2;5) contre 1.6 a (2,1;5), et
    216 a (4,3;7). Diagnostic [MESURE-BAS] sur une trajectoire du moteur
    (diag_actions.log), actions et phase phi = a th1 + b th2 :
      (2,1;5) s = 0.30 : J2/J20 = 1.10, 1.48, 2.70 ; I = 0.500 constant ;
        phi = 2.56 -> 2.05 -> 1.71 (vers pi/2) ; EXPLOSION a t = 773
        (modele : 765).
      (3,2;5) s = 0.25 : J2/J20 oscille entre 0.97 et 3.70 ; I = 1.00 a
        1 % pres ; phi = +2.2, -0.9, +1.2, -1.8, +0.1, +2.9, ... : la
        phase TOURNE ; aucune explosion a 3000.
    Le canal est actif -- l'echange se fait le long de I -- mais
    desaccorde : dans le plan (J2, phi) la trajectoire est fermee.

5.4 Hypothese de mecanisme [DERIV-M1] [POST-HOC] : verrouillage par les
    decalages du second ordre. Les termes non resonants O(eps) (enormes
    sur ce rayon quand delta est petit : X1 + X2 = 4.2 a w2 = 1.5, 2.3 a
    w2 = 2) produisent a O(eps^2) un desaccord a dw1 + b dw2 = eps^2 S ;
    le canal a une largeur eps c/J2 ; il est ouvert ssi eps < eps_L =
    c/(S J2). Parametre de verrouillage L = eps S/c. Le canal est
    VISIBLE a la fenetre T ssi son propre seuil eps_c(T) = G/T est sous
    eps_L, soit T > T_vis = G S/c. Ce que cela explique : (2,1;5) ouvert
    (T_vis ~ 1e2) ; les marginales, ou c est le poids 2^-p d'un seul
    monome contre des non-resonants a gros binomiaux : S/c enorme ;
    votre "<= 5" : S croit avec l'ordre et avec 1/delta sur ce rayon.
    Ce que cela predit, et que votre regle ne predit pas : les piegees
    admises deviennent directes a T > T_vis, avec le F du modele reduit.
    TEST ECRIT AVANT RUN, puis joue [MESURE-BAS] (test_marginal_5_150) :
    5|1.50|+1, 48 valeurs de s dans [0.05, 0.35], T = 25600, prediction
    "deverrouillage a s ~ 0.09 (estimation grossiere de S)" : explosions
    a t = 0.170/eps pour s <~ 0.10 (4 points a 6000-8700 dans la
    fenetre). RESULTAT : 0/46 sous s = 0.32 ; les deux seules explosions
    (0.336, 0.350) a 7400-10000 sont la bande collante sous le seuil
    generique 0.389. Mon estimation de S etait fausse d'au moins x3 ;
    l'hypothese n'est pas morte : elle est bornee -- eps_L < 7e-6,
    S/c > 1.4e5 -- et Q-1 ne l'a jamais testee : a 7|2.50 le seuil de
    canal a T = 6400 vaut s_c = 1.33, AU-DESSUS du seuil generique
    1.229 ; il faut T ~ 1e5 (s_c = 0.30).

5.5 Le test decisif, pour BOCAL4 (le bac a sable ne tient pas 40 min) :
    5|1.50|+1, s dans {0.025, 0.030, 0.035, 0.040}, T = 3e5, avec un
    controle dt/2 sur UNE trajectoire (derive d'energie RK4 sur 5e7
    pas). Predictions du modele reduit deverrouille :
      s = 0.025 : eps = 6.3e-7, t = 2.7e5 ;  s = 0.030 : 1.1e-6, 1.6e5 ;
      s = 0.035 : 1.7e-6, 9.9e4 ;  s = 0.040 : 2.6e-6, 6.6e4.
    Ile exacte : rien. Second test, meme logique : 7|2.50|-1, s dans
    {0.25, 0.30, 0.35}, T = 1e5 (s_c(1e5) = 0.304 ; t = 2.47/eps).
    Si rien ne bouge aux deux, l'hypothese de verrouillage est morte et
    votre lecture "ile" est exacte a tout T pratique ; si le modele
    tient, "PIEGE" est une propriete de la fenetre et le seul enonce
    vrai est T_vis(cellule), calculable.

## 6. REPONSE A "POURQUOI L'ORDRE S'ARRETE A 5"

Il ne s'arrete pas : dans la derivation, aucune clause d'ordre n'existe.
Ce qui existe est L(T) = G S/(c T), et sur CE rayon (X2 = 2/delta, X1 =
(1+w2^2)/delta) il traverse 1 entre l'ordre 5 et l'ordre 7 a T ~ 1e3.
Un autre rayon (par exemple a amplitudes de mode egales) deplacerait la
frontiere. C'est verifiable : la regle d'ordre total est une propriete
(rayon, T), pas du systeme. P-3 calcule S ; alors T_vis se predit par
cellule et la frontiere avec elle.

## 7. SUITE

(a) Vos F(2,1;9) et F(2,1;11) contre 0.01173 et 0.002319 : a lire de
    votre cote, sur pieces (lot v2 non recu ici).
(b) Le test 5.5 sur BOCAL4 ; votre (a') a p = 11 est bon mais ne
    discrimine pas (les deux lectures y predisent la meme chose a
    T = 1600).
(c) P-3 : ETAPE forme normale au second ordre (S par cellule) |
    FICHIERS : aucun run ; le present modele et vos JSON | LIVRABLE :
    T_vis(cellule), kappa, c_p, K_L | CIBLE : la frontiere d'ordre
    devient un nombre par cellule | CLASSE 3.
(d) Promotion des gels : plus d'obstacle de mon cote non plus.

-- FIN note_machine1_reponse_lot_v3_P1_v1 --
