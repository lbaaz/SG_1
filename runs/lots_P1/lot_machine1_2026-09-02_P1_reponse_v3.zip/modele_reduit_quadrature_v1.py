"""Modele resonant reduit (1 ddl) pour le temps d'echappement direct au site a:b, degre p, sur le rayon de la campagne.
Equations rescalees (x = s X, masses UNITE) : X1'' = -X1 + eps (X1+X2)^(p-1), X2'' = -w2^2 X2 - eps (X1+X2)^(p-1),
H = -(P1^2/2 + X1^2/2) + (P2^2/2 + w2^2 X2^2/2) + eps (X1+X2)^p / p,  X_i = sqrt(2 J_i / w_i) cos th_i (w1 = 1).
Terme resonant a O(eps) : H_res = eps c(J) cos(a th1 + b th2),  c(J) = (2/p) sum_{m,n} C(p,m) C(m,(m-a)/2) C(n,(n-b)/2) 2^-p (2J1)^(m/2) (2J2/w2)^(n/2).
Invariant du canal : I = b J1 - a J2. Ligne de niveau : c(J) cos phi = c(J0) cos phi0, |cos phi0| = 1 (vitesses nulles).
Temps d'echappement : t = G/eps,  G = int_{J20}^{inf} dJ2 / ( b sqrt(c(J)^2 - c(J0)^2) ).
Prediction consignee AVANT comparaison pour chaque cellule : F_pred = G (aucun parametre)."""
import numpy as np, json
from math import comb
def G_reduit(p,a,b,w2):
    X1=(1+w2*w2)/(w2*w2-1); X2=2/(w2*w2-1)
    J10=X1**2/2; J20=w2*X2**2/2; I=b*J10-a*J20
    def c(J2):
        J1=(I+a*J2)/b; tot=0.0
        for m in range(a,p+1,2):
            n=p-m
            if n<b or (n-b)%2: continue
            tot+=comb(p,m)*comb(m,(m-a)//2)*comb(n,(n-b)//2)/2**p*(2*J1)**(m/2)*(2*J2/w2)**(n/2)
        return 2*tot/p
    c0=c(J20)
    J=J20*np.exp(np.linspace(1e-7,14,600000)); cc=np.interp(J, J[::100], np.array([c(j) for j in J[::100]]))
    f=1.0/(b*np.sqrt(np.maximum(cc**2-c0**2,1e-300)))
    return float(np.sum(f[1:]*np.diff(J))), c0, I, J20
if __name__=='__main__':
    mes={ (5,2,1,2.0):0.3459, (7,2,1,2.0):0.06113, (7,3,2,1.5):0.00521, (9,3,2,1.5):0.000257, (7,4,1,4.0):2.47 }  # F0 affine, moyenne des deux signes
    out=[]
    for (p,a,b,w2),F in list(mes.items())+[((5,3,2,1.5),None),((5,4,1,4.0),None),((7,5,2,2.5),None),((9,5,2,2.5),None),((9,6,1,6.0),None),((7,4,3,4/3),None),((9,4,3,4/3),None),((9,2,1,2.0),None),((11,2,1,2.0),None)]:
        G,c0,I,J20=G_reduit(p,a,b,w2)
        out.append(dict(p=p,a=a,b=b,w2=w2,G=G,F_mesure=F,c0=c0,I=I))
        print("(%d,%d;%d)@%.3f  F_pred = %-10.4g F_mes = %-9s %s"%(a,b,p,w2,G,("%.4g"%F) if F else '-', ("ecart %+.1f %%"%(100*(G/F-1))) if F else ''))
    json.dump(out, open('/home/claude/modele_reduit_quadrature_v1.json','w'), indent=1)
