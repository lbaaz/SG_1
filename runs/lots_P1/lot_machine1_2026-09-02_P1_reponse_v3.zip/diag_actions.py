"""Diagnostic classe 3 : actions J1, J2 et phase resonante phi = a th1 + b th2 le long d'une trajectoire du moteur depose
(transcription arithmetiquement identique a integrer(), sortie de l'etat tous les 'chaque' pas). Angles : th1 tel que
x1 = sqrt(2J1) cos th1, x1' = +sqrt(2J1) sin th1 (theta1 retrograde, mode fantome) ; x2 = sqrt(2J2/w2) cos th2, x2' = -sqrt(2J2 w2) sin th2."""
import numpy as np, sys, json
sys.path.insert(0,'/home/claude')
from charge_moteur import charger
m=charger()
def traj(p,w2,s,sgn,T,chaque=50):
    m.P=p; dt=m.DT; g=m.G_REF; W1=m.W1; delta=w2*w2-1
    x1=np.array([sgn*s*(1+w2*w2)/delta]); x2=np.array([-sgn*s*(1+W1*W1)/delta]); v1=np.zeros(1); v2=np.zeros(1)
    def acc(a1,a2):
        d1,d2=m.grad_rapide(a1,a2,g); return -W1*W1*a1+d1/delta, -w2*w2*a2-d2/delta
    out=[]
    with np.errstate(over="ignore", invalid="ignore"):
        for n in range(int(round(T/dt))):
            k1v1,k1v2=acc(x1,x2); k1x1,k1x2=v1,v2
            k2v1,k2v2=acc(x1+.5*dt*k1x1,x2+.5*dt*k1x2); k2x1,k2x2=v1+.5*dt*k1v1,v2+.5*dt*k1v2
            k3v1,k3v2=acc(x1+.5*dt*k2x1,x2+.5*dt*k2x2); k3x1,k3x2=v1+.5*dt*k2v1,v2+.5*dt*k2v2
            k4v1,k4v2=acc(x1+dt*k3x1,x2+dt*k3x2); k4x1,k4x2=v1+dt*k3v1,v2+dt*k3v2
            x1=x1+dt/6*(k1x1+2*k2x1+2*k3x1+k4x1); x2=x2+dt/6*(k1x2+2*k2x2+2*k3x2+k4x2)
            v1=v1+dt/6*(k1v1+2*k2v1+2*k3v1+k4v1); v2=v2+dt/6*(k1v2+2*k2v2+2*k3v2+k4v2)
            if not np.isfinite(x1[0]) or max(abs(x1[0]),abs(x2[0]))>m.CAP: out.append(((n+1)*dt,'EXPLOSION')); break
            if (n+1)%chaque==0:
                X1,X2,V1,V2=x1[0]/s,x2[0]/s,v1[0]/s,v2[0]/s          # rescale
                J1=(V1*V1+X1*X1)/2; J2=(V2*V2/w2+w2*X2*X2)/2
                th1=np.arctan2(V1,X1); th2=np.arctan2(-V2/w2,X2)
                out.append(((n+1)*dt,J1,J2,np.mod(th1*0+0,1))) if False else out.append(((n+1)*dt,J1,J2,th1,th2))
    return out
if __name__=='__main__':
    for (p,a,b,w2,s,T) in [(5,3,2,1.5,0.25,3000.0),(5,2,1,2.0,0.30,1200.0)]:
        delta=w2*w2-1; eps=0.05*s**(p-2)/delta
        o=traj(p,w2,s,+1,T,chaque=int(round(20/m.DT)))
        print(f"=== ({a},{b};{p}) w2={w2} s={s} eps={eps:.2e} T={T} ===")
        J20=None
        for rec in o:
            if rec[1]=='EXPLOSION': print("  t=%.0f EXPLOSION"%rec[0]); break
            t,J1,J2,th1,th2=rec; phi=np.mod(a*th1+b*th2+np.pi, 2*np.pi)-np.pi
            if J20 is None: J20=J2
            if int(round(t))%200==0: print("  t=%5.0f  J1=%.4f  J2=%.4f (J2/J20=%.3f)  I=bJ1-aJ2=%.4f  phi=%+.2f"%(t,J1,J2,J2/J20,b*J1-a*J2,phi))
